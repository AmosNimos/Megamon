class Field {
  constructor() {
    this.active = None;
  }
}

class Player {
  constructor() {
    this.pokemons = [];
    this.x = 0;
    this.y = 0;
  }
}