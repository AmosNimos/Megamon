class Pokemon {
  constructor() {
    this.pokemons = [];
    this.x = 0;
    this.y = 0;
  }
}